# CPvP FX - hướng dẫn cho agent (Claude Code)

Mod client-side Fabric cho Minecraft 26.2 (Java 25, Loom `net.fabricmc.fabric-loom`, không remap), chuyên Crystal PvP:
Custom Crystal (ưu tiên số 1), Armor, Totem, Sound Engine, Particle Engine, 10 preset khác nhau thật sự,
Custom Builder, import/export preset, GUI tối-tím, Performance Engine.

## Ràng buộc cứng
- KHÔNG shader/GLSL/bloom/post-processing. Chỉ model, texture, vertex, particle, animation. "Glow" = emissive/additive bằng render type có sẵn của vanilla.
- KHÔNG gọi OpenGL thô. 26.2 có backend Vulkan thử nghiệm bên cạnh OpenGL; mọi thứ đi qua Blaze3D / RenderPipeline của vanilla.
- Không tạo object trong vòng render; hạt dùng `ParticleBuffer`, đối tượng dùng `ObjectPool`; mọi ngân sách lấy từ `PerformanceEngine`.
- Không chạm cơ chế chiến đấu, không tạo lợi thế thông tin trong multiplayer. Tương thích Sodium, Lithium, Meteor Client, mod PvP khác.
- Người dùng chỉ có điện thoại: test trên launcher Android (Zalith / Pojav / Mojo, renderer dịch GL/Vulkan). Mặc định phải nhẹ; cần chế độ Potato dùng được.

## Quy trình bắt buộc
Phân tích -> nền tảng -> tính năng -> kiểm thử sau MỖI module -> tối ưu theo số đo -> bàn giao.
- Không có tính năng giả, không TODO thay chức năng, không tắt tính năng để sửa lỗi.
- Không báo "xong" khi chưa build thành công; không báo "đã tối ưu" khi chưa có số đo.
- Việc chưa làm hoặc chưa kiểm chứng phải ghi rõ trong STATUS.md.

## Việc đầu tiên
1. Chạy `gradle build` (xem README). Sửa phiên bản/plugin trong build.gradle và gradle.properties theo template Fabric chính thức nếu lỗi (các giá trị hiện tại CHƯA được build thử).
2. Chạy `tools/SelfTest.java` (xem README) - phải ALL OK.
3. Tiếp theo: Config System -> hook đo frame time cho `PerformanceEngine.onFrame` -> Crystal Renderer.
Cập nhật STATUS.md sau mỗi bước.
