# CPvP FX (giai đoạn 2a - nền tảng)

Mod client-side cho Fabric, Minecraft 26.2, Java 25. Không dùng shader/bloom/post-processing.

## Build
1. Cài JDK 25.
2. Trong thư mục này chạy `gradle wrapper --gradle-version 9.5.1` (hoặc chép `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` từ template Fabric chính thức; file jar wrapper không tạo được ở đây vì sandbox không có mạng).
3. `./gradlew build` -> file jar ở `build/libs/`.
4. Nếu Gradle báo lỗi phiên bản hoặc plugin: so với template chính thức tại https://fabricmc.net/develop/template/ và gửi nguyên văn lỗi lại.

## Chạy test phần lõi (không cần Minecraft)
Cần JDK (có javac):
```
javac -d out $(find src/main/java -name '*.java' ! -path '*client*') tools/SelfTest.java
java -cp out SelfTest
```
