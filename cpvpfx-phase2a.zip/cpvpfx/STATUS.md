# Trạng thái dự án

## Đã làm và đã kiểm thử (javac + SelfTest, 22 test PASS, JDK 21 trong sandbox)
- ObjectPool, ParticleBuffer (SoA, không cấp phát khi update; đo: 0 byte / 20000 frame)
- QualityGovernor (p95 frame time, trễ + hồi phục chậm, chống dao động)
- QualityLevel / QualityProfile (6 chế độ), PerformanceEngine (facade, distance culling)

## Đã viết nhưng CHƯA build thật (cần chạy Gradle trên máy bạn)
- build.gradle, gradle.properties, settings.gradle, fabric.mod.json
- CpvpFxClient (chỉ dùng ClientModInitializer + slf4j)

## Chưa làm
Config System, GUI, Crystal Renderer, Armor, Totem, Sound Engine, Preset System, Custom Builder,
frustum culling và hook đo frame time (cần API render 26.2 đã xác minh).

## Lưu ý
- Số trong QualityProfile là mặc định thiết kế, chưa đo trên game thật.
- Chưa có số liệu FPS nào; không tuyên bố tối ưu khi chưa đo.
- Bước tiếp theo: build thành công -> Config System -> hook frame time -> Crystal Renderer.
