package com.cpvpfx.client;

import com.cpvpfx.core.perf.PerformanceEngine;
import com.cpvpfx.core.perf.QualityLevel;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client entrypoint. Deliberately uses no Minecraft rendering/GUI API yet:
 * those modules are added one at a time and each must build before the next starts.
 */
public final class CpvpFxClient implements ClientModInitializer {
    public static final String MOD_ID = "cpvpfx";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static PerformanceEngine performance;

    public static PerformanceEngine performance() {
        return performance;
    }

    @Override
    public void onInitializeClient() {
        performance = new PerformanceEngine(QualityLevel.BALANCED, 60);
        LOGGER.info("[{}] initialized (quality={})", MOD_ID, QualityLevel.BALANCED);
    }
}
