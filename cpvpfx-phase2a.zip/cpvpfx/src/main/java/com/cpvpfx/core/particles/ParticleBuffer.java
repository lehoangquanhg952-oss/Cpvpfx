package com.cpvpfx.core.particles;

/**
 * Structure-of-arrays particle storage with a hard cap. All memory is allocated once in the
 * constructor; spawn/update never allocate. Dead particles are removed by swap-with-last (order is not stable).
 * Render thread only.
 */
public final class ParticleBuffer {
    public final float[] x, y, z, vx, vy, vz, age, life, size;
    public final int[] argb;

    private final int capacity;
    private int count;
    private int limit;
    private long rejected;

    public ParticleBuffer(int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be > 0");
        this.capacity = capacity;
        this.limit = capacity;
        x = new float[capacity]; y = new float[capacity]; z = new float[capacity];
        vx = new float[capacity]; vy = new float[capacity]; vz = new float[capacity];
        age = new float[capacity]; life = new float[capacity]; size = new float[capacity];
        argb = new int[capacity];
    }

    /** @return false if the particle was not created (at limit, or non-positive lifetime). */
    public boolean spawn(float px, float py, float pz, float pvx, float pvy, float pvz,
                         float lifeSeconds, float particleSize, int colorArgb) {
        if (lifeSeconds <= 0f) return false;
        if (count >= limit) {
            rejected++;
            return false;
        }
        int i = count++;
        x[i] = px; y[i] = py; z[i] = pz;
        vx[i] = pvx; vy[i] = pvy; vz[i] = pvz;
        age[i] = 0f; life[i] = lifeSeconds; size[i] = particleSize; argb[i] = colorArgb;
        return true;
    }

    /** Lowers/raises the active cap (0..capacity). Particles above a lowered cap are dropped immediately. */
    public void setLimit(int newLimit) {
        limit = Math.max(0, Math.min(capacity, newLimit));
        if (count > limit) count = limit;
    }

    public void update(float dt, float gravity, float drag) {
        final float damp = Math.max(0f, 1f - drag * dt);
        int i = 0;
        while (i < count) {
            float a = age[i] + dt;
            if (a >= life[i]) {
                removeAt(i);          // last particle moves into i; re-check the same index
                continue;
            }
            age[i] = a;
            vy[i] -= gravity * dt;
            vx[i] *= damp; vy[i] *= damp; vz[i] *= damp;
            x[i] += vx[i] * dt; y[i] += vy[i] * dt; z[i] += vz[i] * dt;
            i++;
        }
    }

    private void removeAt(int i) {
        int last = --count;
        if (i == last) return;
        x[i] = x[last]; y[i] = y[last]; z[i] = z[last];
        vx[i] = vx[last]; vy[i] = vy[last]; vz[i] = vz[last];
        age[i] = age[last]; life[i] = life[last]; size[i] = size[last]; argb[i] = argb[last];
    }

    public void clear() { count = 0; }
    public int count() { return count; }
    public int capacity() { return capacity; }
    public int limit() { return limit; }
    public long rejected() { return rejected; }
}
