package com.cpvpfx.core.perf;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Fixed-capacity object pool. NOT thread-safe: use from the render thread only.
 * Allocation happens only on a pool miss. Releasing the same object twice is a caller bug.
 */
public final class ObjectPool<T> {
    private final Object[] slots;
    private final Supplier<? extends T> factory;
    private final Consumer<? super T> resetter;
    private int size;
    private long hits, misses, dropped;

    public ObjectPool(int capacity, Supplier<? extends T> factory, Consumer<? super T> resetter) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity must be > 0");
        this.slots = new Object[capacity];
        this.factory = factory;
        this.resetter = resetter;
    }

    /** Pre-creates objects up to capacity so the first frames do not allocate. */
    public void prewarm(int count) {
        int n = Math.min(count, slots.length - size);
        for (int i = 0; i < n; i++) slots[size++] = factory.get();
    }

    @SuppressWarnings("unchecked")
    public T acquire() {
        if (size > 0) {
            hits++;
            T t = (T) slots[--size];
            slots[size] = null;
            return t;
        }
        misses++;
        return factory.get();
    }

    public void release(T item) {
        if (item == null) return;
        resetter.accept(item);
        if (size < slots.length) slots[size++] = item;
        else dropped++;
    }

    public int available() { return size; }
    public long hits() { return hits; }
    public long misses() { return misses; }
    public long dropped() { return dropped; }
}
