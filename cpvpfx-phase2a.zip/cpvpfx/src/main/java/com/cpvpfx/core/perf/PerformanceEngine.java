package com.cpvpfx.core.perf;

/** Facade the effect modules query for their current budgets. Render thread only. */
public final class PerformanceEngine {
    private final QualityGovernor governor;
    private QualityLevel level;
    private QualityProfile profile;
    private float renderDistSq;

    public PerformanceEngine(QualityLevel level, int targetFps) {
        this.governor = new QualityGovernor(targetFps);
        setLevel(level);
    }

    public void setLevel(QualityLevel newLevel) {
        this.level = newLevel;
        apply(QualityProfile.of(newLevel));
    }

    public void setCustomProfile(QualityProfile custom) {
        this.level = QualityLevel.CUSTOM;
        apply(custom);
    }

    private void apply(QualityProfile p) {
        this.profile = p;
        this.renderDistSq = p.renderDistance() * p.renderDistance();
    }

    public void setAdaptive(boolean on) { governor.setEnabled(on); }
    public void setTargetFps(int fps) { governor.setTargetFps(fps); }
    public void onFrame(long frameNanos) { governor.onFrame(frameNanos); }

    public int effectiveParticleLimit() { return Math.max(0, Math.round(profile.particleLimit() * governor.scale())); }
    public int effectiveMaxEffects() { return Math.max(1, Math.round(profile.maxActiveEffects() * governor.scale())); }
    public float effectiveDensity() { return profile.effectDensity() * governor.scale(); }

    /** Distance culling. Render distance is intentionally not scaled by the governor (avoids visible pop-in). */
    public boolean withinRenderDistance(double dx, double dy, double dz) {
        return dx * dx + dy * dy + dz * dz <= renderDistSq;
    }

    public QualityLevel level() { return level; }
    public QualityProfile profile() { return profile; }
    public QualityGovernor governor() { return governor; }
}
