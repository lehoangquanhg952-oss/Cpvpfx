package com.cpvpfx.core.perf;

import java.util.Arrays;

/**
 * Adaptive quality scale in [floor, 1]. Decisions use the 95th-percentile frame time over the last
 * 120 frames (stability, not average FPS) so a single hitch does not trigger a reduction.
 * Reduces only after sustained slowness, recovers slowly, and backs off if recovery causes a relapse.
 * Allocation-free after construction. Render thread only.
 */
public final class QualityGovernor {
    private static final int WINDOW = 120;
    private static final int EVAL_EVERY = 30;
    private static final float MAX_SAMPLE_MS = 250f;
    private static final float REDUCE_FACTOR = 1.25f;   // p95 above target*1.25 => too slow
    private static final float RECOVER_FACTOR = 1.10f;  // p95 below target*1.10 => stable at target
    private static final int BASE_RECOVER = 6;          // evaluations of stability before one recovery step

    private final float[] frameMs = new float[WINDOW];
    private final float[] scratch = new float[WINDOW];
    private int idx, filled, sinceEval;

    private float targetMs;
    private float floorScale = 0.35f;
    private float scale = 1f;
    private boolean enabled = true;

    private int badStreak, goodStreak, cooldown;
    private int recoverNeeded = BASE_RECOVER;
    private int evalsSinceRecover = Integer.MAX_VALUE / 2;
    private float lastSlowMs;
    private int reductions, recoveries;

    public QualityGovernor(int targetFps) {
        setTargetFps(targetFps);
    }

    public void setTargetFps(int fps) {
        targetMs = 1000f / Math.max(20, Math.min(360, fps));
    }

    public void setFloorScale(float floor) {
        floorScale = Math.max(0.1f, Math.min(1f, floor));
        if (scale < floorScale) scale = floorScale;
    }

    public void setEnabled(boolean on) {
        enabled = on;
        if (!on) scale = 1f;
    }

    public void reset() {
        scale = 1f; idx = 0; filled = 0; sinceEval = 0;
        badStreak = 0; goodStreak = 0; cooldown = 0;
        recoverNeeded = BASE_RECOVER; evalsSinceRecover = Integer.MAX_VALUE / 2;
    }

    /** Call once per rendered frame with that frame's duration. */
    public void onFrame(long frameNanos) {
        float ms = Math.min(MAX_SAMPLE_MS, frameNanos / 1_000_000f);
        frameMs[idx] = ms;
        idx = (idx + 1) % WINDOW;
        if (filled < WINDOW) filled++;
        if (++sinceEval >= EVAL_EVERY) {
            sinceEval = 0;
            evaluate();
        }
    }

    private void evaluate() {
        System.arraycopy(frameMs, 0, scratch, 0, filled);
        Arrays.sort(scratch, 0, filled);
        lastSlowMs = scratch[Math.min(filled - 1, (int) (filled * 0.95f))];
        if (evalsSinceRecover < Integer.MAX_VALUE / 2) evalsSinceRecover++;
        if (!enabled || filled < WINDOW) return;
        if (cooldown > 0) { cooldown--; return; }

        if (lastSlowMs > targetMs * REDUCE_FACTOR) {
            goodStreak = 0;
            if (++badStreak >= 2) {
                badStreak = 0;
                if (scale > floorScale) {
                    scale = Math.max(floorScale, scale - 0.125f);
                    reductions++;
                    if (evalsSinceRecover <= 20) recoverNeeded = Math.min(48, recoverNeeded * 2);
                    cooldown = 3;
                }
            }
        } else if (lastSlowMs < targetMs * RECOVER_FACTOR) {
            badStreak = 0;
            if (scale < 1f && ++goodStreak >= recoverNeeded) {
                goodStreak = 0;
                scale = Math.min(1f, scale + 0.0625f);
                recoveries++;
                evalsSinceRecover = 0;
                if (scale >= 1f) recoverNeeded = BASE_RECOVER;
            }
        } else {
            badStreak = 0;
            goodStreak = 0;
        }
    }

    public float scale() { return scale; }
    public float slowFrameMs() { return lastSlowMs; }
    public int reductions() { return reductions; }
    public int recoveries() { return recoveries; }
}
