package com.cpvpfx.core.perf;

public enum QualityLevel { POTATO, PERFORMANCE, BALANCED, HIGH, ULTRA, CUSTOM }
