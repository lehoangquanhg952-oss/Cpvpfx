package com.cpvpfx.core.perf;

/**
 * Per-level budgets. The numbers in {@link #of(QualityLevel)} are INITIAL DEFAULTS chosen by design,
 * not measured results: they must be tuned against real frame-time measurements.
 */
public record QualityProfile(
        int particleLimit,
        int maxActiveEffects,
        float effectDensity,     // 0..1 multiplier on particles spawned per effect
        int updateHz,            // simulation update rate for effects
        float renderDistance,    // blocks
        int modelDetail,         // 0..3
        int textureQuality,      // 0..3
        int animationQuality,    // 0..3
        int soundLimit) {        // max simultaneous custom sounds

    public QualityProfile {
        if (particleLimit < 0) throw new IllegalArgumentException("particleLimit < 0");
        if (maxActiveEffects < 1) throw new IllegalArgumentException("maxActiveEffects < 1");
        if (!(effectDensity >= 0f && effectDensity <= 1f)) throw new IllegalArgumentException("effectDensity not in 0..1");
        if (updateHz < 5 || updateHz > 240) throw new IllegalArgumentException("updateHz not in 5..240");
        if (renderDistance < 8f) throw new IllegalArgumentException("renderDistance < 8");
        if (modelDetail < 0 || modelDetail > 3) throw new IllegalArgumentException("modelDetail not in 0..3");
        if (textureQuality < 0 || textureQuality > 3) throw new IllegalArgumentException("textureQuality not in 0..3");
        if (animationQuality < 0 || animationQuality > 3) throw new IllegalArgumentException("animationQuality not in 0..3");
        if (soundLimit < 1) throw new IllegalArgumentException("soundLimit < 1");
    }

    public static QualityProfile of(QualityLevel level) {
        return switch (level) {
            case POTATO      -> new QualityProfile(128, 4, 0.25f, 20, 24f, 0, 0, 0, 4);
            case PERFORMANCE -> new QualityProfile(384, 8, 0.50f, 30, 40f, 1, 1, 1, 8);
            case BALANCED, CUSTOM -> new QualityProfile(1024, 16, 0.75f, 60, 64f, 2, 2, 2, 12);
            case HIGH        -> new QualityProfile(2048, 32, 1.00f, 60, 96f, 3, 3, 3, 16);
            case ULTRA       -> new QualityProfile(4096, 64, 1.00f, 120, 128f, 3, 3, 3, 24);
        };
    }
}
