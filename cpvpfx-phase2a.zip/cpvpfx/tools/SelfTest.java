import com.cpvpfx.core.particles.ParticleBuffer;
import com.cpvpfx.core.perf.*;
import java.lang.management.ManagementFactory;
import java.util.Arrays;

public final class SelfTest {
    static int failures;

    static void check(boolean ok, String msg) {
        System.out.println((ok ? "PASS " : "FAIL ") + msg);
        if (!ok) failures++;
    }

    static void feed(QualityGovernor g, int n, float ms) {
        long ns = (long) (ms * 1_000_000f);
        for (int i = 0; i < n; i++) g.onFrame(ns);
    }

    public static void main(String[] args) {
        poolTests();
        particleTests();
        governorTests();
        profileTests();
        allocationTest();
        System.out.println(failures == 0 ? "ALL OK" : failures + " FAILED");
        if (failures > 0) System.exit(1);
    }

    static void poolTests() {
        int[] created = {0};
        ObjectPool<StringBuilder> p = new ObjectPool<>(2, () -> { created[0]++; return new StringBuilder(); }, sb -> sb.setLength(0));
        p.prewarm(5);
        check(created[0] == 2, "pool: prewarm limited to capacity");
        StringBuilder s1 = p.acquire(), s2 = p.acquire(), s3 = p.acquire();
        check(p.hits() == 2 && p.misses() == 1, "pool: hits/misses counted");
        s1.append("x"); s2.append("y");
        p.release(s1); p.release(s2); p.release(s3);
        check(p.dropped() == 1, "pool: overflow is dropped, not grown");
        check(p.acquire().length() == 0 && p.acquire().length() == 0, "pool: objects are reset on release");
    }

    static void particleTests() {
        ParticleBuffer pb = new ParticleBuffer(8);
        boolean allOk = true;
        for (int i = 0; i < 8; i++) allOk &= pb.spawn(i, 0, 0, 0, 0, 0, 1f, 1f, -1);
        check(allOk && pb.count() == 8, "particles: fills to capacity");
        check(!pb.spawn(0, 0, 0, 0, 0, 0, 1f, 1f, -1) && pb.rejected() == 1, "particles: spawn rejected at cap");
        pb.setLimit(4);
        check(pb.count() == 4, "particles: lowering limit trims immediately");
        check(!pb.spawn(0, 0, 0, 0, 0, 0, 1f, 1f, -1), "particles: spawn blocked above lowered limit");

        ParticleBuffer sw = new ParticleBuffer(4);
        float[] lives = {0.1f, 1f, 0.1f, 1f};
        for (int i = 0; i < 4; i++) sw.spawn(i, 0, 0, 0, 0, 0, lives[i], 1f, -1);
        sw.update(0.2f, 0f, 0f);
        float[] left = {sw.x[0], sw.x[1]};
        Arrays.sort(left);
        check(sw.count() == 2 && left[0] == 1f && left[1] == 3f, "particles: swap-remove keeps the right survivors");

        ParticleBuffer ph = new ParticleBuffer(1);
        ph.spawn(0, 0, 0, 2f, 0, 0, 10f, 1f, -1);
        ph.update(0.5f, 0f, 0f);
        check(Math.abs(ph.x[0] - 1f) < 1e-5f, "particles: velocity integration");
        ph.update(0.5f, 10f, 0f);
        check(Math.abs(ph.vy[0] - (-5f)) < 1e-4f, "particles: gravity applied");
    }

    static void governorTests() {
        QualityGovernor g = new QualityGovernor(60);
        feed(g, 600, 8f);
        check(g.scale() == 1f && g.reductions() == 0, "governor: no change when fast and stable");

        g = new QualityGovernor(60);
        feed(g, 300, 8f);
        g.onFrame(200_000_000L);
        feed(g, 600, 8f);
        check(g.reductions() == 0, "governor: a single hitch does not reduce quality");

        g = new QualityGovernor(60);
        feed(g, 3000, 30f);
        check(Math.abs(g.scale() - 0.35f) < 1e-4f, "governor: sustained slowness drops to the floor (scale=" + g.scale() + ")");
        feed(g, 6000, 10f);
        check(g.scale() == 1f, "governor: recovers to full quality when fast again");

        g = new QualityGovernor(60);
        feed(g, 3000, 30f);
        int r = g.reductions();
        feed(g, 6000, 1000f / 60f);
        check(g.scale() == 1f && g.reductions() == r, "governor: recovers under a vsync-locked 60 fps without bouncing (scale=" + g.scale() + ")");

        g = new QualityGovernor(60);
        for (int i = 0; i < 12000; i++) g.onFrame((long) ((8f + 14f * g.scale()) * 1_000_000f));
        int changes = g.reductions() + g.recoveries();
        check(changes <= 8 && g.scale() >= 0.7f && g.scale() <= 0.95f,
                "governor: settles instead of oscillating (scale=" + g.scale() + ", changes=" + changes + ")");

        g = new QualityGovernor(60);
        g.setEnabled(false);
        feed(g, 3000, 40f);
        check(g.scale() == 1f, "governor: disabled governor never reduces");
    }

    static void profileTests() {
        boolean monotonic = true;
        QualityLevel[] order = {QualityLevel.POTATO, QualityLevel.PERFORMANCE, QualityLevel.BALANCED, QualityLevel.HIGH, QualityLevel.ULTRA};
        for (int i = 1; i < order.length; i++) {
            QualityProfile a = QualityProfile.of(order[i - 1]), b = QualityProfile.of(order[i]);
            monotonic &= b.particleLimit() >= a.particleLimit() && b.maxActiveEffects() >= a.maxActiveEffects()
                    && b.renderDistance() >= a.renderDistance();
        }
        check(monotonic, "profiles: budgets never decrease from Potato to Ultra");
        boolean threw = false;
        try { new QualityProfile(10, 0, 0.5f, 60, 32f, 1, 1, 1, 4); } catch (IllegalArgumentException e) { threw = true; }
        check(threw, "profiles: invalid values are rejected");
        PerformanceEngine pe = new PerformanceEngine(QualityLevel.BALANCED, 60);
        check(pe.withinRenderDistance(10, 0, 0) && !pe.withinRenderDistance(100, 0, 0), "engine: distance culling");
        check(pe.effectiveParticleLimit() == 1024, "engine: full budget at scale 1");
    }

    static void allocationTest() {
        com.sun.management.ThreadMXBean bean = (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
        long tid = Thread.currentThread().threadId();
        ParticleBuffer pb = new ParticleBuffer(4096);
        for (int i = 0; i < 4096; i++) pb.spawn(0, 0, 0, 1, 1, 1, 1_000_000f, 1f, -1);
        QualityGovernor g = new QualityGovernor(60);
        for (int i = 0; i < 20000; i++) { pb.update(0.016f, 9.8f, 0.1f); g.onFrame(16_000_000L); }
        long before = bean.getThreadAllocatedBytes(tid);
        long t0 = System.nanoTime();
        for (int i = 0; i < 20000; i++) { pb.update(0.016f, 9.8f, 0.1f); g.onFrame(16_000_000L); }
        long t1 = System.nanoTime();
        long delta = bean.getThreadAllocatedBytes(tid) - before;
        check(delta < 2048, "allocation: 20000 frames x 4096 particles allocated " + delta + " bytes");
        System.out.printf("INFO  update of 4096 particles: %.1f us/frame (sandbox CPU, NOT representative of your PC)%n",
                (t1 - t0) / 20000.0 / 1000.0);
    }
}
